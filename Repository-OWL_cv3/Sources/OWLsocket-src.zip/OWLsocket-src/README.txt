MRSsocket for use on the Raspberry PI Compute Modules as used in the Owl-Bots

MRSsocket.c is the Source Code

MRSsocket is a compiled version compiled on :

(uname -a)
Linux raspberrypi 4.4.13+ #894 Mon Jun 13 12:43:26 BST 2016 armv6l GNU/Linux

lsb_release -a)
Distributor ID: Raspbian
Description:    Raspbian GNU/Linux 8.0 (jessie)
Release:        8.0
Codename:       jessie

using the command as in the source file

i.e. pi@raspberry:~ $



M.R.Simpson 26/05/2017

Version 2 generated to correct from LEFT RIGHT NECK to RIGHT LEFT NECK as per Python code to interface with existing OpenCV

PFC renamed to OWLsocket run-time to make it easy for students
